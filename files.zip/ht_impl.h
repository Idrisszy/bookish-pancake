#ifndef HT_IMPL_H
#define HT_IMPL_H

#include <stdint.h>

// Define the hash table entry structure
typedef struct ht_entry {
    char *key;
    void *value;
    struct ht_entry *next;
} ht_entry;

// Define the hash table structure
struct hash_table {
    size_t size;
    ht_entry **entries;
};

#endif // HT_IMPL_H