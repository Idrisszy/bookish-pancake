#include <stdlib.h>
#include <string.h>
#include "ht.h"
#include "ht_impl.h"

// Function to create a new hash table
ht *ht_create(size_t size) {
    ht *table = malloc(sizeof(ht));
    table->size = size;
    table->entries = calloc(size, sizeof(ht_entry *));
    return table;
}

// Function to destroy a hash table
void ht_destroy(ht *table) {
    for (size_t i = 0; i < table->size; i++) {
        ht_entry *entry = table->entries[i];
        while (entry != NULL) {
            ht_entry *next = entry->next;
            free(entry->key);
            free(entry);
            entry = next;
        }
    }
    free(table->entries);
    free(table);
}

// Function to insert a key-value pair into the hash table
int ht_insert(ht *table, const char *key, void *value) {
    // Hash the key to get the index
    size_t index = hash(key) % table->size;

    // Create a new entry
    ht_entry *entry = malloc(sizeof(ht_entry));
    entry->key = strdup(key);
    entry->value = value;
    entry->next = table->entries[index];
    table->entries[index] = entry;

    return 0;
}

// Function to look up a key in the hash table
void *ht_lookup(const ht *table, const char *key) {
    size_t index = hash(key) % table->size;
    ht_entry *entry = table->entries[index];
    while (entry != NULL) {
        if (strcmp(entry->key, key) == 0) {
            return entry->value;
        }
        entry = entry->next;
    }
    return NULL;
}

// Function to remove a key from the hash table
int ht_remove(ht *table, const char *key) {
    size_t index = hash(key) % table->size;
    ht_entry *entry = table->entries[index];
    ht_entry *prev = NULL;
    while (entry != NULL) {
        if (strcmp(entry->key, key) == 0) {
            if (prev == NULL) {
                table->entries[index] = entry->next;
            } else {
                prev->next = entry->next;
            }
            free(entry->key);
            free(entry);
            return 0;
        }
        prev = entry;
        entry = entry->next;
    }
    return -1;
}

// Example hash function
static size_t hash(const char *key) {
    size_t hash = 5381;
    int c;
    while ((c = *key++)) {
        hash = ((hash << 5) + hash) + c;
    }
    return hash;
}