#include <stdio.h>
#include "ht.h"

int main() {
    // Create a hash table
    ht *table = ht_create(100);

    // Insert key-value pairs into the hash table
    ht_insert(table, "Ardy", "MATLAB");
    ht_insert(table, "Abdullah", "C");
    ht_insert(table, "Dhara", "Python");
    ht_insert(table, "Salwa", "C");

    // Look up values by key
    printf("Ardy's favorite language: %s\n", (char *)ht_lookup(table, "Ardy"));
    printf("Abdullah's favorite language: %s\n", (char *)ht_lookup(table, "Abdullah"));
    printf("Dhara's favorite language: %s\n", (char *)ht_lookup(table, "Dhara"));
    printf("Salwa's favorite language: %s\n", (char *)ht_lookup(table, "Salwa"));

    // Remove a key-value pair
    ht_remove(table, "Salwa");

    // Try to look up the removed key
    if (ht_lookup(table, "Salwa") == NULL) {
        printf("Salwa's favorite language not found.\n");
    }

    // Destroy the hash table
    ht_destroy(table);

    return 0;
}