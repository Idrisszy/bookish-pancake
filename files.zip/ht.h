#ifndef HT_H
#define HT_H

#include <stddef.h>

// Define the hash table structure
typedef struct hash_table ht;

// Function prototypes
ht *ht_create(size_t size);
void ht_destroy(ht *table);
int ht_insert(ht *table, const char *key, void *value);
void *ht_lookup(const ht *table, const char *key);
int ht_remove(ht *table, const char *key);

#endif // HT_H